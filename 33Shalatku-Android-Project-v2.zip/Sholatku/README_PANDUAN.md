# As-Shalah — Proyek Android (WebView + Floating Window)

## Cara build APK lewat HP (GitHub Actions)
1. Buat akun & repositori baru di github.com (boleh private).
2. Di repo: **Add file → Create new file**, nama file ketik persis `.github/workflows/build.yml`, lalu tempel isi file `.github/workflows/build.yml` dari ZIP ini → Commit.
3. **Add file → Upload files**, unggah ZIP ini (tidak perlu diekstrak) → Commit. Workflow otomatis membuka ZIP dan membangun APK.
   (Jika tidak jalan sendiri: tab **Actions → Build APK → Run workflow**.)
4. Tunggu ±5–8 menit sampai centang hijau, buka run-nya, bagian **Artifacts** → unduh `Sholatku-debug-apk` (ZIP berisi `app-debug.apk`), ekstrak, lalu install.

## Setelah install
- Saat pertama dibuka, ketuk **Izinkan** pada pesan baterai agar azan tetap bunyi saat aplikasi ditutup / layar mati.
- HP Xiaomi/Oppo/Vivo/Realme: di Pengaturan → Aplikasi → As-Shalah, aktifkan **Mulai otomatis** dan **Tanpa pembatasan baterai**.
- Izinkan **Tampil di atas aplikasi lain** (SYSTEM_ALERT_WINDOW) dan **Notifikasi**.
- Matikan optimasi baterai untuk As-Shalah agar azan tetap tepat waktu saat HP lama dikunci.
- Ganti nada azan: menu AZAN → "➕ Tambah dari HP" → pilih file mp3 → pilih di "Pilihan Suara" → SIMPAN.

## Struktur
- `app/src/main/assets/index.html` — aplikasi HTML Anda
- `PrayerService.kt` — penjadwal azan/iqomah/hati² (foreground service + AlarmManager)
- `Overlay.kt` — jendela mengambang (WindowManager)
- `AlertActivity.kt` + `HatiUi.kt` — tampilan di layar kunci & tampilan HATI²
