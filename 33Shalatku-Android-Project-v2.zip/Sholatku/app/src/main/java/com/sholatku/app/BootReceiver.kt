package com.sholatku.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        try {
            Store.setDzikirOn(context, false)
            ContextCompat.startForegroundService(
                context,
                Intent(context, PrayerService::class.java).setAction(PrayerService.ACT_TICK)
            )
        } catch (e: Exception) {
        }
    }
}
